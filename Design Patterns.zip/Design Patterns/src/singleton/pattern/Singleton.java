package singleton.pattern;

public class Singleton {

    private static Singleton obj = null;

    private Singleton() {

    }

    public static Singleton instance() {

        if (obj == null) {
            obj = new Singleton();
        }

        return obj;
    }
}