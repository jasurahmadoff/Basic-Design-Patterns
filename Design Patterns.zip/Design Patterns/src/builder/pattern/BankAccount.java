package builder.pattern;

public class BankAccount {

    private long accountNumber;
    private String owner;
    private String branch;
    private double balance;
    private double interestRate;

    private BankAccount() {

    }

    public BankAccount(long accountNumber, String owner, String branch, double balance, double interestRate) {
        this.accountNumber = accountNumber;
        this.owner = owner;
        this.branch = branch;
        this.balance = balance;
        this.interestRate = interestRate;
    }

    public long getAccountNumber() {
        return accountNumber;
    }

    public String getOwner() {
        return owner;
    }

    public String getBranch() {
        return branch;
    }

    public double getBalance() {
        return balance;
    }

    public double getInterestRate() {
        return interestRate;
    }

    @Override
    public String toString() {
        return "BankAccount {"
                + "accountNumber = " + accountNumber
                + ", owner = " + owner
                + ", branch = " + branch
                + ", balance = " + balance
                + ", interestRate = " + interestRate + "}";
    }

    public static class Builder {

        BankAccount b = null;

        public Builder() {
            b = new BankAccount();
        }

        public Builder theAccountNumber(long accountNumber) {
            b.accountNumber = accountNumber;
            return this;
        }

        public Builder withOwner(String owner) {
            b.owner = owner;
            return this;
        }

        public Builder atBranch(String branch) {
            b.branch = branch;
            return this;
        }

        public Builder openingBalance(double balance) {
            b.balance = balance;
            return this;
        }

        public Builder atRate(double interestRate) {
            b.interestRate = interestRate;
            return this;
        }

        public BankAccount build() {
            return new BankAccount(b.accountNumber, b.owner, b.branch, b.balance, b.interestRate);
        }
    }
}