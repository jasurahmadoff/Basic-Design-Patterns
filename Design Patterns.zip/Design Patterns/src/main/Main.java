package main;

import builder.pattern.BankAccount;
import singleton.pattern.Singleton;

public class Main {

    public static void main(String[] args) {

    }

    public static void operateSingletonPattern() {

        Singleton obj1 = Singleton.instance();
        Singleton obj2 = Singleton.instance();

        System.out.println(obj1 == obj2);
    }

    public static void operateBuilderPattern() {

        BankAccount account = new BankAccount.Builder()
                .theAccountNumber(1)
                .withOwner("Jasur Ahmadov")
                .atBranch("Engineering")
                .openingBalance(207.0)
                .atRate(4.0)
                .build();

        BankAccount anotherAccount = new BankAccount.Builder()
                .theAccountNumber(2)
                .withOwner("Kamil Heydarli")
                .atBranch("Marketing")
                .openingBalance(105.4)
                .atRate(2.5)
                .build();

        System.out.println(account);
        System.out.println(anotherAccount);
    }
}